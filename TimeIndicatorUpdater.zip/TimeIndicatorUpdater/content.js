function waitForVideoElement() {
    const observer = new MutationObserver((mutations, observer) => {
        const video = document.querySelector('video');
        if (video) {
            console.log('Video element found:', video);
            setupVideoListeners(video);
            observer.disconnect();  // Stop observing after setting up listeners
        }
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
}

function setupVideoListeners(video) {
    console.log('Initial playback rate:', video.playbackRate);
    video.addEventListener('ratechange', function () {
        console.log('Playback rate changed to:', video.playbackRate);
        updateDisplays(video);
    });

    video.addEventListener('loadedmetadata', function () {
        console.log('Video metadata loaded');
        updateDisplays(video);  // Update displays once metadata is loaded
    });

    // Continuously update current time display to overcome YouTube's updates
    setInterval(() => {
        updateCurrentTimeDisplay(video);
    }, 0.01); // Update more frequently to enforce synchronization

    updateDisplays(video);  // Also update display initially
}

function updateDisplays(video) {
    const durationDisplay = document.querySelector('.ytp-time-duration');
    if (video && durationDisplay) {
        const rate = video.playbackRate;
        const adjustedDuration = isNaN(video.duration) ? 0 : video.duration / rate;
        durationDisplay.textContent = formatTime(adjustedDuration);
        console.log('Updated duration display to:', formatTime(adjustedDuration));
    } else {
        console.log('Failed to find the duration display element.');
    }
}

function updateCurrentTimeDisplay(video) {
    const currentTimeDisplay = document.querySelector('.ytp-time-current');
    if (video && currentTimeDisplay) {
        const rate = video.playbackRate;
        currentTimeDisplay.textContent = formatTime(video.currentTime / rate);
    }
}

function formatTime(time) {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
}

waitForVideoElement();
